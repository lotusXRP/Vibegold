
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import stripe
import os

app = FastAPI()

stripe.api_key = os.getenv("STRIPE_SECRET_KEY", "sk_test_YOUR_SECRET_KEY_HERE")

origins = ["*"]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class CheckoutRequest(BaseModel):
    item_id: str
    quantity: int

PRODUCT_MAP = {
    "starter_kit": {"price": "price_starterkit_id", "quantity": 1},
    "refill_pack": {"price": "price_refill_id", "quantity": 1},
    "collectors_edition": {"price": "price_collector_id", "quantity": 1},
}

@app.post("/create-checkout-session")
async def create_checkout_session(req: CheckoutRequest):
    item = PRODUCT_MAP.get(req.item_id)
    if not item:
        return {"error": "Invalid product ID"}
    try:
        session = stripe.checkout.Session.create(
            line_items=[{"price": item["price"], "quantity": req.quantity}],
            mode="payment",
            success_url="https://vibegold.com/success",
            cancel_url="https://vibegold.com/cancel",
        )
        return {"checkout_url": session.url}
    except Exception as e:
        return {"error": str(e)}
